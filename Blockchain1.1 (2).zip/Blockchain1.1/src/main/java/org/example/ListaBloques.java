package org.example;
import java.util.ArrayList;

import java.util.List;
public class ListaBloques {
    private static List<Bloque> blockchain;

    public ListaBloques() {
        this.blockchain = new ArrayList<>();
        // Agrega el bloque genesis a la cadena de bloques
        blockchain.add(new Bloque(new String[]{}, 0)); // Bloque inicial sin bloque anterior
    }

    public void agregarBloque(Bloque bloque) {
        Bloque ultimoBloque = obtenerUltimoBloque();
        bloque.setPreviousBlockChain(ultimoBloque.getBlockchain());
        blockchain.add(bloque);
    }

    public static List<Bloque> getBlockchain() {
        return blockchain;
    }
    public Bloque obtenerUltimoBloque() {
        if (blockchain.isEmpty()) {
            return null;
        }
        return blockchain.get(blockchain.size() - 1);
    }

    public List<String> getHistorialTransacciones() {
        List<String> historial = new ArrayList<>();
        for (Bloque bloque : blockchain) {
            for (String transaccion : bloque.getTransacciones()) {
                historial.add(transaccion);
            }
        }
        return historial;
    }
    public void verCadenaBloques() {
        System.out.println("=== CADENA DE BLOQUES ===");
        for (int i = 0; i < blockchain.size(); i++) {
            Bloque bloque = blockchain.get(i);
            System.out.println("Bloque " + i + ":");
            System.out.println("Hash: " + bloque.getHash());
            System.out.println("Hash del bloque anterior: " + bloque.getPreviousBlockChain());
            System.out.println("Transacciones:");
            for (String transaccion : bloque.getTransacciones()) {
                System.out.println("\t" + transaccion);
            }}
    }


    public boolean esValida() {
        if (blockchain.isEmpty()) {
            return true;
        }
        // Verificar la cadena de bloques para asegurar que cada bloque apunta al anterior
        for (int i = 1; i < blockchain.size(); i++) {
            Bloque bloqueActual = blockchain.get(i);
            Bloque bloqueAnterior = blockchain.get(i - 1);
            if (bloqueActual.getPreviousBlockChain() != bloqueAnterior.getBlockchain()) {
                return false;
            }
        }
        return true;
    }

    public int size() {
        return blockchain.size();
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Cadena de Bloques:\n");
        for (int i = 0; i < blockchain.size(); i++) {
            Bloque bloque = blockchain.get(i);
            builder.append("Bloque ").append(i).append(":\n");
            builder.append("Hash: ").append(bloque.getHash()).append("\n");
            builder.append("Hash del bloque anterior: ").append(bloque.getPreviousBlockChain()).append("\n");
            builder.append("Transacciones:\n");
            for (String transaccion : bloque.getTransacciones()) {
                builder.append("\t").append(transaccion).append("\n");
            }
            builder.append("\n");
        }
        return builder.toString();
    }
}

