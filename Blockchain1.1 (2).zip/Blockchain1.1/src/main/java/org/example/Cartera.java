package org.example;

import java.security.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Cartera {
    private Map<String, Double> saldos;
    private Map<String, KeyPair> claves;
    private static List<String> historialTransacciones = new ArrayList<>();
    private ListaBloques listaBloques;

    public Cartera() {
        this.saldos = new HashMap<>();
        this.claves = new HashMap<>();
    }

    public Map<String, Double> getSaldos() {
        return saldos;
    }

    public void agregarUsuario(String usuario) {
        try {
            KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
            keyGen.initialize(2048);
            KeyPair pair = keyGen.generateKeyPair();
            claves.put(usuario, pair);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
    }

    public PublicKey getClavePublica(String usuario) {
        return claves.get(usuario).getPublic();
    }

    public PrivateKey getClavePrivada(String usuario) {
        return claves.get(usuario).getPrivate();
    }

    public void agregarSaldo(String usuario, double saldo) {
        saldos.put(usuario, saldo);
    }

    public double obtenerSaldo(String usuario) {
        return saldos.getOrDefault(usuario, 0.0);
    }

    public void realizarTransaccion(String emisor, String receptor, double cantidad) {
        double saldoEmisor = obtenerSaldo(emisor);
        double saldoReceptor = obtenerSaldo(receptor);

        if (saldoEmisor >= cantidad) {
            saldos.put(emisor, saldoEmisor - cantidad);
            saldos.put(receptor, saldoReceptor + cantidad);
            agregarTransaccion(cantidad, emisor, receptor); // El primer parámetro debe ser la cantidad
            System.out.println("Transacción exitosa: " + cantidad + " Lps transferidos de " + emisor + " a " + receptor);
        } else {
            System.out.println("Error: Saldo insuficiente para realizar la transacción.");
        }
    }

    public static void agregarTransaccion(double cantidad, String emisor, String receptor) {
        historialTransacciones.add("Transacción: " + cantidad + " Lps de " + emisor + " a " + receptor);
    }

    public static List<String> getHistorialTransacciones() {
        return historialTransacciones;

    }
    public void verCadenaBloques() {
        List<Bloque> blockchain = listaBloques.getBlockchain();
        System.out.println("\n=== CADENA DE BLOQUES ===");
        for (Bloque bloque : blockchain) {
            System.out.println(bloque);
        }
    }
}