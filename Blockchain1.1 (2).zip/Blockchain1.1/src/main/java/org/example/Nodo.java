package org.example;

public class Nodo {
    private String direccion;
    private ListaBloques listaBloques;
    private Cartera cartera;

    public Nodo(String direccion, ListaBloques listaBloques, Cartera cartera) {
            this.direccion = direccion;
            this.listaBloques = listaBloques;
        this.cartera = cartera;
        }

        public String getDireccion() {
            return direccion;
        }

        public void setDireccion(String direccion) {
            this.direccion = direccion;
        }

        public ListaBloques getListaBloques() {
            return listaBloques;
        }

        public void setListaBloques(ListaBloques listaBloques) {
            this.listaBloques = listaBloques;
        }

        // Otros métodos según sea necesario

}
