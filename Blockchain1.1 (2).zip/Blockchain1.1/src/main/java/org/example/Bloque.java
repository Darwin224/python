package org.example;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;

public class Bloque {
        private int previousBlockChain;
        private int blockchain;
    private ArrayList<String> transacciones;


    public Bloque(String[] transacciones, int previousBlockChain) {
        this.transacciones = new ArrayList<>();

        for (String transaccion : transacciones) {
            this.transacciones.add(transaccion);
        }
        this.previousBlockChain = previousBlockChain;
        this.blockchain = calcularHash();
    }

    public void agregarTransaccion(String transaccion) {
        this.transacciones.add(transaccion);
    }

    public int getPreviousBlockChain() {
        return previousBlockChain;
    }

    public void setPreviousBlockChain(int previousBlockChain) {
        this.previousBlockChain = previousBlockChain;
    }

    public int getBlockchain() {
        return blockchain;
    }

    public void setBlockchain(int blockchain) {
        this.blockchain = blockchain;
    }

    public ArrayList<String> getTransacciones() {
        return transacciones;
    }

    public void setTransacciones(ArrayList<String> transacciones) {
        this.transacciones = transacciones;
    }

    private int calcularHash() {
        StringBuilder input = new StringBuilder();
        input.append(previousBlockChain);
        for (String transaccion : transacciones) {
            input.append(transaccion);
        }

        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] messageDigest = md.digest(input.toString().getBytes(StandardCharsets.UTF_8));

            BigInteger number = new BigInteger(1, messageDigest);
            return number.intValue(); // Convertir el hash a un entero
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    public String getHash() {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(Integer.toString(blockchain).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public String toString() {
        return "Bloque{" +
                "previousBlockChain='" + previousBlockChain + '\'' +
                ", blockchain=" + blockchain +
                ", transacciones=" + transacciones +
                ", hash='" + getHash() + '\'' +
                '}';
    }

}






