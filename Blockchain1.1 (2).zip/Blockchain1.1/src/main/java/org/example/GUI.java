package org.example;

import javax.swing.*;
import java.util.stream.Collectors;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GUI extends JFrame {

    private JPanel panel;
    private JButton botonAgregarDinero;
    private JButton botonConsultarSaldo;
    private JButton botonRealizarTransaccion;
    private JButton botonVerHistorialTransacciones;
    private JButton botonVerCadenaBloques;
    private JButton botonSalir;
    private Cartera cartera;
    private ListaBloques listaBloques;


    public GUI(Cartera cartera, ListaBloques listaBloques) {
       this.cartera = cartera;
        this.listaBloques = listaBloques;

        this.setTitle("Cartera de transacciones");
        this.setSize(500, 300);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        panel = new JPanel();
        panel.setLayout(new GridLayout(6, 1));

        botonAgregarDinero = new JButton("Agregar dinero a cartera");
        botonConsultarSaldo = new JButton("Consultar saldo");
        botonRealizarTransaccion = new JButton("Realizar transacción");
        botonVerHistorialTransacciones = new JButton("Ver historial de transacciones");
        botonVerCadenaBloques = new JButton("Ver cadena de bloques");
        botonSalir = new JButton("Salir");

        botonAgregarDinero.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarDineroACartera();
            }
        });

        botonConsultarSaldo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                consultarSaldo();
            }
        });


        botonRealizarTransaccion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                realizarTransaccion();
            }
        });

        botonVerHistorialTransacciones.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                verHistorialTransacciones();
            }
        });

        botonVerCadenaBloques.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               verCadenaBloques();
            }
        });

        botonSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        panel.add(botonAgregarDinero);
        panel.add(botonConsultarSaldo);
        panel.add(botonRealizarTransaccion);
        panel.add(botonVerHistorialTransacciones);
        panel.add(botonVerCadenaBloques);
        panel.add(botonSalir);

        this.add(panel);
    }
    public static void main(String[] args) {
        Cartera cartera = new Cartera();
        ListaBloques listaBloques = new ListaBloques();
        GUI gui = new GUI(cartera, listaBloques);
        gui.setVisible(true);

    }

    private void agregarDineroACartera() {
        String usuario = JOptionPane.showInputDialog(this, "Ingresa tu nombre de usuario: ");
        String cantidad = JOptionPane.showInputDialog(this, "Ingresa la cantidad a agregar: ");
        cartera.agregarSaldo(usuario, Double.parseDouble(cantidad));

        System.out.println("Se han agregado " + cantidad + " Lps a la cuenta de " + usuario);
        JOptionPane.showMessageDialog(this, "Se han agregado " + cantidad + " Lps a la cuenta de " + usuario);
    }

    private void consultarSaldo() {
        String usuario = JOptionPane.showInputDialog(this, "Ingresa tu nombre de usuario: ");
        double saldo = cartera.obtenerSaldo(usuario);
        System.out.println("El saldo de " + usuario + " es: " + saldo + " Lps");
        JOptionPane.showMessageDialog(this, "El saldo de " + usuario + " es: " + saldo + " Lps");
    }

    private void realizarTransaccion() {
        String emisor = JOptionPane.showInputDialog(this, "Ingresa el usuario emisor: ");
        String receptor = JOptionPane.showInputDialog(this, "Ingresa el usuario receptor: ");
        String cantidad = JOptionPane.showInputDialog(this, "Ingresa la cantidad a transferir: ");
        cartera.realizarTransaccion(emisor, receptor, Double.parseDouble(cantidad));

        JOptionPane.showMessageDialog(this, "Transacción exitosa: " + cantidad + " Lps transferidos de " + emisor + " a " + receptor);
    }
    private void verHistorialTransacciones() {
        StringBuilder historial = new StringBuilder();
        for (String transaccion : cartera.getHistorialTransacciones()) {
            historial.append(transaccion).append("\n");
        }

        System.out.println("=== HISTORIAL DE TRANSACCIONES ===");
        System.out.println(historial.toString());

        JOptionPane.showMessageDialog(this, "=== HISTORIAL DE TRANSACCIONES ===\n" + historial.toString());
    }
    public GUI(ListaBloques listaBloques) {
        this.listaBloques = listaBloques;
    }

    public void verCadenaBloques() {
        System.out.println("=== CADENA DE BLOQUES ===");
        System.out.println("Número de bloques: " + listaBloques.size());
        System.out.println(listaBloques.toString());

    }
    private ListaBloques obtenerListaBloques() {
        return listaBloques;
    }
}
