package org.example;

import java.util.Random;
import java.util.Scanner;

public class Blockchain {
    private static ListaBloques listaBloques = new ListaBloques();
    private static Cartera cartera = new Cartera();
    private static Nodo nodo1 = new Nodo("Nodo1", listaBloques, cartera);
    private static Nodo nodo2 = new Nodo("Nodo2", listaBloques, cartera);
    private static Random random = new Random();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion;
        ListaBloques listaBloques = new ListaBloques();
        for (int i = 0; i < 4; i++) {
            String[] transacciones = {"Transacción " + (i + 1)};
            Bloque bloque;
            if (listaBloques.size() > 0) {
                bloque = new Bloque(transacciones, listaBloques.obtenerUltimoBloque().getBlockchain());
            } else {
                bloque = new Bloque(transacciones, 0);
            }
            listaBloques.agregarBloque(bloque);
        }

        Cartera cartera = new Cartera();
        GUI gui = new GUI(cartera, listaBloques);
        gui.setVisible(true);



        do {
            mostrarMenu();
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    agregarDineroACartera();
                    break;
                case 2:
                    consultarSaldo();
                    break;
                case 3:
                    realizarTransaccion();
                    break;
                case 4:
                    verHistorialTransacciones();
                    break;
                case 5:
                    verCadenaBloques();
                    break;
                case 6:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción no válida. Por favor, elige una opción del menú.");
            }
        } while (opcion != 6);
    }

    private static void mostrarMenu() {
        System.out.println("\n=== MENÚ ===");
        System.out.println("1. Agregar dinero a cartera");
        System.out.println("2. Consultar saldo");
        System.out.println("3. Realizar transacciones");
        System.out.println("4. Ver historial de transacciones");
        System.out.println("5. Ver cadena de bloques");
        System.out.println("6. Salir");
        System.out.print("Elige una opción: " + "\n");
    }

    private static void agregarDineroACartera() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingresa tu nombre de usuario: ");
        String usuario = scanner.nextLine();
        System.out.print("Ingresa la cantidad a agregar: ");
        double cantidad = scanner.nextDouble();
        cartera.agregarSaldo(usuario, cantidad);
        System.out.println("Se han agregado " + cantidad + " Lps a la cuenta de " + usuario);
    }

    private static void consultarSaldo() {
        if (cartera.getSaldos().isEmpty()) {
            System.out.println("La cartera está vacía. No hay usuarios registrados.");
            return;
        }
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingresa el usuario: ");
        String usuario = scanner.nextLine();
        double saldo = cartera.obtenerSaldo(usuario);
        System.out.println("El saldo de " + usuario + " es: " + saldo + " Lps");
    }

    private static void realizarTransaccion() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingresa el usuario emisor: ");
        String emisor = scanner.nextLine();
        System.out.print("Ingresa el usuario receptor: ");
        String receptor = scanner.nextLine();
        System.out.print("Ingresa la cantidad a transferir: ");
        double cantidad = scanner.nextDouble();
       cartera.realizarTransaccion(emisor, receptor, cantidad);
      //  Transaccion nuevaTransaccion = new Transaccion(emisor, receptor, cantidad);

        System.out.println("Transacción realizada con éxito.");
    }

    private static void verHistorialTransacciones() {
        System.out.println("\n=== HISTORIAL DE TRANSACCIONES ===");
        for (String transaccion : Cartera.getHistorialTransacciones()) {
            System.out.println(transaccion);
        }
    }

    private static void verCadenaBloques() {
        System.out.println("\n=== CADENA DE BLOQUES ===");
        for (Bloque bloque : ListaBloques.getBlockchain()) {
            System.out.println(bloque);
        }
    }
}







